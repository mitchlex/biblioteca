<?php
const base_url = "http://localhost/new/";
const host = "localhost";
const user = "root";
const pass = "";
const db = "bibliotecas";
const charset = "charset=utf8";
?>